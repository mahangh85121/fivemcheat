#pragma once

#include "imgui.h"

namespace ImGui
{
	IMGUI_API bool Toggle(const char* label, bool* v);


}