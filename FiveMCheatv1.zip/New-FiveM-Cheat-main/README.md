# New-FiveM-Cheat

This source is dtc but working fine , it's not clean code so don't be trash , it's like a "alpha" version 
There is part of exec , sorry i was making something

Features :
- Aimbot ( Visible check, magic bullet, adaptive weapon, fov, smooth, distance)
- Visuals ( Visible check, playername, weapon name, box , skeleton, healhbar)
- Self ( Godmod, invisible, anti hs, noclip, no ragdoll, no gravity)
- Weapon ( No recoil, no spread, damage boost, infinite ammo, no reload, give weapon)
- Vehicle ( Vehicle esp, custom car, godmod, boost, unlock all car, warp vehicle)
- Misc (Crosshair, hotkey)
- Config (Save configs, load configs)
- Playerlist ( Troll Option ) 
- Vehicle list ( Troll Option ) 
- native invoker
- Integrated login(keyauth)
- You can use reshade 

Pasters will paste, and kitsune too 
![image](https://user-images.githubusercontent.com/62155427/198326962-1096e8d6-5278-46a7-9ab8-94c44022af88.png)
