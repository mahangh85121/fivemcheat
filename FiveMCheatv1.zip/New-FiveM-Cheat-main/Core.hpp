#pragma once

#include "includes.hpp"

namespace Core
{
	bool Init();
}